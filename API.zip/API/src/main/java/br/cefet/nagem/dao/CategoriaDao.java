package br.cefet.nagem.dao;

import br.cefet.nagem.model.Categoria;
import java.util.List;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

@RegisterBeanMapper(Categoria.class)
public interface CategoriaDao{
    @GetGeneratedKeys
    @SqlUpdate("insert into categoria(descricao) values (:descricao)")
    int insert(@BindBean Categoria categoria);
    
    @SqlQuery("select * "
             + "from categoria "
             + "where idCategoria = :idCategoria;")
    Categoria get(@Bind("idCategoria") int idCategoria);
    
    @SqlQuery("select * "
            + " from categoria "
            + " order by descricao;")
    List<Categoria> getAll();
        
    @SqlUpdate("update categoria "
            + " set descricao = :descricao "
            + " where idCategoria = :idCategoria;")
    int update(@BindBean Categoria categoria);
    
    @SqlUpdate("delete "
            + " from categoria "
            + " where idCategoria = :idCategoria;")
    int delete(@Bind("idCategoria") int idCategoria);

    
}


