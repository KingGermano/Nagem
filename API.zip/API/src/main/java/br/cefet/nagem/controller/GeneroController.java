package br.cefet.nagem.controller;

import br.cefet.nagem.model.Genero;
import br.cefet.nagem.service.GeneroService;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/v1/genero")
public class GeneroController {

    private final GeneroService generoService;

    public GeneroController(GeneroService generoService){
        this.generoService = generoService;
    }

    @GetMapping({"/", ""})
    public List<Genero> consultarTodos(){
        List<Genero> generoList = generoService.consultarTodos();
        return generoList;
    }

    @GetMapping("/{id}")
    public Genero consultarGenero(@PathVariable("id") int id){
        Genero ret = generoService.consultarPorId(id);
        return ret;
    }

    @PostMapping({"", "/"})
    public Genero inserir(@RequestBody Genero genero){
        Genero ret = generoService.inserir(genero);
        return ret;
    }

    @PutMapping({"", "/"})
    public Genero alterar(@RequestBody Genero genero){
        generoService.alterar(genero);
        return genero;
    }

    @DeleteMapping("/{id}")
    public Genero deletar(@PathVariable("id") int id){
        Genero genero = generoService.consultarPorId(id);
        if (genero == null){
            throw new RuntimeException("Nao existe aluno com este id para ser excluido....");
        }
        generoService.excluir(id);
        return genero;
    }
}
