package br.cefet.nagem.dao;

import br.cefet.nagem.model.Usuario;
import java.util.List;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

@RegisterBeanMapper(Usuario.class)
public interface UsuarioDao {

        @GetGeneratedKeys
        @SqlUpdate("insert into usuario (email, nick_name, dt_nasc, senha) values (:email, :nick_name, :dt_nasc, :senha)")
        int insert(@BindBean Usuario usuario);

        @SqlQuery("select * "
                        + " from usuario "
                        + " where idUsuario = :idUsuario;")
        Usuario get(@Bind("idUsuario") int idUsuario);

        @SqlQuery("select * "
                        + " from usuario "
                        + " order by nick_name;")
        List<Usuario> getAll();

        @SqlQuery("select * "
                        + " from usuario "
                        + " where email like :email "
                        + " order by nick_name;")
        List<Usuario> getAllByEmail(@Bind("email") String email);

        @SqlUpdate("update usuario "
                        + " set email = :email, "
                        + " nick_name = :nick_name, " + "dt_nasc = :dt_nasc"
                        + " where idUsuario = :idUsuario;")
        int update(@BindBean Usuario usuario);

        @SqlUpdate("delete "
                        + " from usuario "
                        + " where idUsuario = :idUsuario;")
        int delete(@Bind("idUsuario") int idUsuario);

        @SqlQuery("select * "
        + "from usuario "
        + "where email like :email;")
        Usuario getByEmail(String email);

        @SqlQuery("select * "
        + "from usuario "
        + "where email like :email "
        + "and email = 'victorgermano2005@gmail.com';")
        Usuario getAdmin(String email);

}
