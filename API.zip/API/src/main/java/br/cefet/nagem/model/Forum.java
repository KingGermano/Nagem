
package br.cefet.nagem.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString

public class Forum {
    private int idForum;
    private String obra;
    private String data_forum;
    private String descricao;
    private int idGenero;
    private int idCategoria;
    private int idUsuario;
    private Usuario usuario;
    private Categoria categoria;
    private Genero genero;
}