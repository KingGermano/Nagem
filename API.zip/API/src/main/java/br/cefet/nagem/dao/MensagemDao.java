package br.cefet.nagem.dao;

import br.cefet.nagem.model.Mensagem;

import java.util.List;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

@RegisterBeanMapper(Mensagem.class)
public interface MensagemDao {

        @GetGeneratedKeys
        @SqlUpdate("insert into mensagem (texto, idUsuario, idForum, hora) values (:texto, :idUsuario, :idForum, :hora)")
        int insert(@BindBean Mensagem mensagem);

        @SqlQuery("select * "
                        + " from mensagem "
                        + " where idMensagem = :idMensagem;")
        Mensagem get(@Bind("idMensagem") int idMensagem);

        @SqlQuery("select * "
                        + " from mensagem "
                        + " order by hora;")
        List<Mensagem> getAll();

        @SqlQuery("select * "
                        + " from mensagem "
                        + " where idForum = :idForum "
                        + " order by hora;")
        List<Mensagem> getAllByForum(@Bind("idForum") int idForum);

        @SqlUpdate("update mensagem "
                        + " set texto = :texto, "
                        + " idUsuario = :idUsuario, " 
                        + " idForum = :idForum"
                        + " where idMensagem = :idMensagem;")
        int update(@BindBean Mensagem mensagem);

        @SqlUpdate("delete "
                        + " from mensagem "
                        + " where idMensagem = :idMensagem;")
        int delete(@Bind("idMensagem") int idMensagem);
}
