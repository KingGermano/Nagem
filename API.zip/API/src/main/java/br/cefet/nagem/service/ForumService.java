package br.cefet.nagem.service;

import br.cefet.nagem.dao.CategoriaDao;
import br.cefet.nagem.dao.ForumDao;
import br.cefet.nagem.dao.GeneroDao;
import br.cefet.nagem.dao.UsuarioDao;
import br.cefet.nagem.model.Categoria;
import br.cefet.nagem.model.Forum;
import br.cefet.nagem.model.Genero;
import br.cefet.nagem.model.Usuario;

import java.util.List;
import org.jdbi.v3.core.Jdbi;
import org.springframework.stereotype.Service;

@Service
public class ForumService {

    private final ForumDao forumDao;
    private final UsuarioDao usuarioDao;
    private final GeneroDao generoDao;
    private final CategoriaDao categoriaDao;

    public ForumService(Jdbi jdbi) {
        this.forumDao = jdbi.onDemand(ForumDao.class);
        this.usuarioDao = jdbi.onDemand(UsuarioDao.class);
        this.generoDao = jdbi.onDemand(GeneroDao.class);
        this.categoriaDao = jdbi.onDemand(CategoriaDao.class);
    }

    public Forum inserir(Forum forum) {
        int idForum = forumDao.insert(forum);
        forum.setIdForum(idForum);
        return forum;
    }

    public List<Forum> consultarTodos() {
        List<Forum> forumList = forumDao.getAll();

        for (Forum forum : forumList) {
            Usuario usuario = usuarioDao.get(forum.getIdUsuario());
            forum.setUsuario(usuario);

            Genero genero = generoDao.get(forum.getIdGenero());
            forum.setGenero(genero);

            Categoria categoria = categoriaDao.get(forum.getIdCategoria());
            forum.setCategoria(categoria);
        }

        return forumList;
    }

    public Forum consultarPorId(int id) {
        Forum forum = forumDao.get(id);

        if (forum != null) {
            Usuario usuario = usuarioDao.get(forum.getIdUsuario());
            forum.setUsuario(usuario);

            Genero genero = generoDao.get(forum.getIdGenero());
            forum.setGenero(genero);

            Categoria categoria = categoriaDao.get(forum.getIdCategoria());
            forum.setCategoria(categoria);
        }

        return forum;
    }

    public void alterar(Forum forum) {
        forumDao.update(forum);
    }

    public void excluir(int id) {
        forumDao.delete(id);
    }

    public List<Forum> consultarTodosPorUsuario(int idUsuario) {
        return forumDao.getAllByUsuario(idUsuario);
    }
}
