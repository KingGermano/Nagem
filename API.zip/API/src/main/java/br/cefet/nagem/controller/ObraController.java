package br.cefet.nagem.controller;

import br.cefet.nagem.model.Obra;
import br.cefet.nagem.service.ObraService;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/v1/obra")
public class ObraController {

    private final ObraService obraService;

    public ObraController(ObraService obraService){
        this.obraService = obraService;
    }

    @GetMapping({"/", ""})
    public List<Obra> consultarTodos(){
        List<Obra> obraList = obraService.consultarTodos();
        return obraList;
    }

    @GetMapping("/{id}")
    public Obra consultarObra(@PathVariable("id") int id){
        Obra ret = obraService.consultarPorId(id);
        return ret;
    }

    @PostMapping({"", "/"})
    public Obra inserir(@RequestBody Obra obra){
        Obra ret = obraService.inserir(obra);
        return ret;
    }

    @PutMapping({"", "/"})
    public Obra alterar(@RequestBody Obra obra){
        obraService.alterar(obra);
        return obra;
    }

    @DeleteMapping("/{id}")
    public Obra deletar(@PathVariable("id") int id){
        Obra obra = obraService.consultarPorId(id);
        if (obra == null){
            throw new RuntimeException("Nao existe aluno com este id para ser excluido....");
        }
        obraService.excluir(id);
        return obra;
    }
}
