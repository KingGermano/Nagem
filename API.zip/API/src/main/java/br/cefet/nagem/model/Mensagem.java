
package br.cefet.nagem.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString

public class Mensagem {
    private int idMensagem;
    private String texto;
    private String hora;
    private int idUsuario;
    private Usuario usuario;
    private int idForum;
    private Forum forum;
}