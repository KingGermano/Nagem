package br.cefet.nagem.service;

import br.cefet.nagem.dao.ObraDao;
import br.cefet.nagem.dao.GeneroDao;
import br.cefet.nagem.model.Obra;
import br.cefet.nagem.model.Genero;
import java.util.List;
import org.jdbi.v3.core.Jdbi;
import org.springframework.stereotype.Service;

@Service
public class GeneroService {

    private final GeneroDao generoDao;
    private final ObraDao obraDao;

    public GeneroService(Jdbi jdbi) {
        this.generoDao = jdbi.onDemand(GeneroDao.class);
        this.obraDao = jdbi.onDemand(ObraDao.class);
    }

    public Genero inserir(Genero genero) {
        int idGenero = generoDao.insert(genero);
        genero.setIdGenero(idGenero);
        return genero;
    }

    public List<Genero> consultarTodos() {
        List<Genero> generoList = generoDao.getAll();

        for (Genero genero : generoList) {
            List<Obra> obraList = obraDao.getAllByGenero(genero.getIdGenero());
            genero.setObras(obraList);
        }

        return generoList;
    }

    public Genero consultarPorId(int id) {
        Genero genero = generoDao.get(id);

        if (genero != null) {
            List<Obra> obraList = obraDao.getAllByGenero(genero.getIdGenero());
            genero.setObras(obraList);
        }

        return genero;
    }

    public void alterar(Genero genero) {
        generoDao.update(genero);
    }

    public void excluir(int id) {
        generoDao.delete(id);
    }

}
