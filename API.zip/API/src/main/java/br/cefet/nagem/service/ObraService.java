package br.cefet.nagem.service;

import br.cefet.nagem.dao.ForumDao;
import br.cefet.nagem.dao.ObraDao;
import br.cefet.nagem.model.Forum;
import br.cefet.nagem.model.Obra;
import java.util.List;
import org.jdbi.v3.core.Jdbi;
import org.springframework.stereotype.Service;

@Service
public class ObraService {

    private final ObraDao obraDao;
    private final ForumDao forumDao;

    public ObraService(Jdbi jdbi) {
        this.obraDao = jdbi.onDemand(ObraDao.class);
        this.forumDao = jdbi.onDemand(ForumDao.class);
    }

    public Obra inserir(Obra obra) {
        int idObra = obraDao.insert(obra);
        obra.setIdObra(idObra);
        return obra;
    }

    public List<Obra> consultarTodos() {
        List<Obra> obraList = obraDao.getAll();

        for (Obra obra : obraList) {
            List<Forum> forumList = forumDao.getAllByObra(obra.getIdObra());
            obra.setForums(forumList);
        }

        return obraList;
    }

    public Obra consultarPorId(int id) {
        Obra obra = obraDao.get(id);

        if (obra != null) {
            List<Forum> forumList = forumDao.getAllByObra(obra.getIdObra());
            obra.setForums(forumList);
        }

        return obra;
    }

    public void alterar(Obra obra) {
        obraDao.update(obra);
    }

    public void excluir(int id) {
        obraDao.delete(id);
    }

}
