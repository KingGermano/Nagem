
package br.cefet.nagem.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString

public class Usuario {
    private int idUsuario;
    private String email;
    private String senha;
    private String nick_name;
    private String dt_nasc;
    private List<Forum> forums;
}