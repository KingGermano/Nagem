package br.cefet.nagem.service;

import br.cefet.nagem.dao.ForumDao;
import br.cefet.nagem.dao.UsuarioDao;
import br.cefet.nagem.model.Forum;
import br.cefet.nagem.model.Usuario;
import java.util.List;
import org.jdbi.v3.core.Jdbi;
import org.springframework.stereotype.Service;

@Service
public class UsuarioService {

    private final UsuarioDao usuarioDao;
    private final ForumDao forumDao;
    private final EmailService emailService;

    public UsuarioService(Jdbi jdbi, EmailService emailService) {
        this.usuarioDao = jdbi.onDemand(UsuarioDao.class);
        this.forumDao = jdbi.onDemand(ForumDao.class);
        this.emailService = emailService;
    }

    public Usuario inserir(Usuario usuario) {
        int idUsuario = usuarioDao.insert(usuario);
        usuario.setIdUsuario(idUsuario);
        return usuario;
    }

    public List<Usuario> consultarTodos() {
        List<Usuario> usuarioList = usuarioDao.getAll();

        for (Usuario usuario : usuarioList) {
            List<Forum> forumList = forumDao.getAllByUsuario(usuario.getIdUsuario());
            usuario.setForums(forumList);
        }

        return usuarioList;
    }

    public Usuario consultarPorId(int id) {
        Usuario usuario = usuarioDao.get(id);

        if (usuario != null) {
            List<Forum> forumList = forumDao.getAllByUsuario(usuario.getIdUsuario());
            usuario.setForums(forumList);
        }

        return usuario;
    }

    public void alterar(Usuario usuario) {
        usuarioDao.update(usuario);
    }

    public void excluir(int id) {
        usuarioDao.delete(id);
    }

    public Usuario getByEmail(String email) {
        Usuario usuario = usuarioDao.getByEmail(email);
        return usuario;
    }

    public Usuario getAdmin(String email) {
        Usuario usuario = usuarioDao.getAdmin(email);
        return usuario;
    }

    public void recuperarSenha(Usuario usuario) {
        String texto = "NAGEM - O SEU APP DE ENTRETENIMENTO \n \nUsuário " + usuario.getNick_name() + ", sua senha é '"+ usuario.getSenha() +"'. \n \n Até logo. ;)";
        emailService.sendSimpleMessage(usuario.getEmail(), "Recuperação de senha", texto);
    }
}
