package br.cefet.nagem.dao;

import br.cefet.nagem.model.Forum;
import java.util.List;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

@RegisterBeanMapper(Forum.class)
public interface ForumDao {

        @GetGeneratedKeys
        @SqlUpdate("insert into forum (obra, data_forum, descricao, idGenero, idCategoria, idUsuario) values (:obra, :data_forum, :descricao, :idGenero, :idCategoria, :idUsuario)")
        int insert(@BindBean Forum forum);

        @SqlQuery("select * "
                        + " from forum "
                        + " where idForum = :idForum;")
        Forum get(@Bind("idForum") int idForum);

        @SqlQuery("select * "
                        + " from forum "
                        + " order by obra;")
        List<Forum> getAll();

        @SqlQuery("select * "
                        + " from forum "
                        + " where obra like :obra "
                        + " order by obra;")
        List<Forum> getAllByObra(@Bind("obra") String obra);

        @SqlQuery("select * "
                        + " from forum "
                        + " where idObra = :idObra "
                        + " order by idObra;")
        List<Forum> getAllByObra(@Bind("idObra") int idObra);

        @SqlQuery("select * "
                        + " from forum "
                        + " where idUsuario = :idUsuario "
                        + " order by obra;")
        List<Forum> getAllByUsuario(@Bind("idUsuario") int idUsuario);

        @SqlUpdate("update forum "
                        + " set obra = :obra, "
                        + " data_forum = :data_forum, " + "descricao = :descricao, idGenero = :idGenero, idCategoria = :idCategoria,  idUsuario = :idUsuario"
                        + " where idForum = :idForum;")
        int update(@BindBean Forum forum);

        @SqlUpdate("delete "
                        + " from forum "
                        + " where idForum = :idForum;")
        int delete(@Bind("idForum") int idForum);

}
