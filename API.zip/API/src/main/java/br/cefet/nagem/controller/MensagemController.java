package br.cefet.nagem.controller;

import br.cefet.nagem.model.Mensagem;
import br.cefet.nagem.service.MensagemService;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/v1/mensagem")
public class MensagemController {

    private final MensagemService mensagemService;

    public MensagemController(MensagemService mensagemService){
        this.mensagemService = mensagemService;
    }

    @GetMapping({"/", ""})
    public List<Mensagem> consultarTodos(){
        List<Mensagem> mensagemList = mensagemService.consultarTodos();
        return mensagemList;
    }

    @GetMapping("/{id}")
    public Mensagem consultarMensagem(@PathVariable("id") int id){
        Mensagem ret = mensagemService.consultarPorId(id);
        return ret;
    }

    @GetMapping("/forum/{idForum}")
    public List<Mensagem> consultarMensagensForum(@PathVariable("idForum") int idForum){
        List<Mensagem> mensagemList = mensagemService.consultarMensagensForum(idForum);
        return mensagemList;
    }

    @PostMapping({"", "/"})
    public Mensagem inserir(@RequestBody Mensagem Mensagem){
        Mensagem ret = mensagemService.inserir(Mensagem);
        return ret;
    }

    @PutMapping({"", "/"})
    public Mensagem alterar(@RequestBody Mensagem Mensagem){
        mensagemService.alterar(Mensagem);
        return Mensagem;
    }

    @DeleteMapping("/{id}")
    public Mensagem deletar(@PathVariable("id") int id){
        Mensagem Mensagem = mensagemService.consultarPorId(id);
        if (Mensagem == null){
            throw new RuntimeException("Nao existe mensagem com este id para ser excluido....");
        }
        mensagemService.excluir(id);
        return Mensagem;
    }
}
