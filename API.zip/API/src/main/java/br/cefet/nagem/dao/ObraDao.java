package br.cefet.nagem.dao;

import br.cefet.nagem.model.Obra;
import java.util.List;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

@RegisterBeanMapper(Obra.class)
public interface ObraDao {

        @GetGeneratedKeys
        @SqlUpdate("insert into obra (idade, nome, idGenero) values (:idade, :nome, :idGenero)")
        int insert(@BindBean Obra obra);

        @SqlQuery("select * "
                        + " from obra "
                        + " where idObra = :idObra;")
        Obra get(@Bind("idObra") int idObra);

        @SqlQuery("select * "
                        + " from obra "
                        + " order by nome;")
        List<Obra> getAll();

        @SqlQuery("select * "
                        + " from obra "
                        + " where idade like :idade "
                        + " order by nome;")
        List<Obra> getAllByIdade(@Bind("idade") String idade);

        @SqlQuery("select * "
                        + " from obra "
                        + " where idGenero = :idGenero "
                        + " order by nome;")
        List<Obra> getAllByGenero(@Bind("idGenero") int idGenero);

        @SqlUpdate("update obra "
                        + " set idade = :idade, "
                        + "     nome = :nome, idGenero = :idGenero"
                        + " where idObra = :idObra;")
        int update(@BindBean Obra obra);

        @SqlUpdate("delete "
                        + " from obra "
                        + " where idObra = :idObra;")
        int delete(@Bind("idObra") int idObra);

}
