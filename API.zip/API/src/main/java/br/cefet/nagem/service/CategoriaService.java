package br.cefet.nagem.service;

import br.cefet.nagem.dao.CategoriaDao;
import br.cefet.nagem.model.Categoria;

import java.util.List;
import org.jdbi.v3.core.Jdbi;
import org.springframework.stereotype.Service;

@Service
public class CategoriaService {

    private final CategoriaDao categoriaDao;

    public CategoriaService(Jdbi jdbi) {
        this.categoriaDao = jdbi.onDemand(CategoriaDao.class);
    }

    public Categoria inserir(Categoria categoria) {
        int idCategoria = categoriaDao.insert(categoria);
        categoria.setIdCategoria(idCategoria);
        return categoria;
    }

    public List<Categoria> consultarTodos() {
        List<Categoria> categoriaList = categoriaDao.getAll();

        // for (Categoria categoria : categoriaList) {
        //     List<Genero> generoList = generoDao.getAllByCategoria(categoria.getIdCategoria());
        //     categoria.setGeneros(generoList);
        // }

        return categoriaList;
    }

    public Categoria consultarPorId(int id) {
        Categoria categoria = categoriaDao.get(id);

        // if (categoria != null) {
        //     List<Genero> generoList = generoDao.getAllByCategoria(categoria.getIdCategoria());
        //     categoria.setGeneros(generoList);
        // }

        return categoria;
    }

    public void alterar(Categoria categoria) {
        categoriaDao.update(categoria);
    }

    public void excluir(int id) {
        categoriaDao.delete(id);
    }

}
