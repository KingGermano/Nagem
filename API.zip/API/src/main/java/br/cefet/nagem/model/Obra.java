
package br.cefet.nagem.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString

public class Obra {
    private int idObra;
    private String idade;
    private String nome;
    private int idGenero;
    private List<Forum> forums;
}