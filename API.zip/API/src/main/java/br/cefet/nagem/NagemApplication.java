package br.cefet.nagem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NagemApplication {

	public static void main(String[] args) {
		SpringApplication.run(NagemApplication.class, args);
	}
}