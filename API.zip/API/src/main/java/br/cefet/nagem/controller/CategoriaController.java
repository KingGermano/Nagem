/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.cefet.nagem.controller;

import br.cefet.nagem.model.Categoria;
import br.cefet.nagem.service.CategoriaService;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/v1/categoria")
public class CategoriaController {
    
    private final CategoriaService categoriaService;
    
    public CategoriaController(CategoriaService categoriaService){
        this.categoriaService = categoriaService;
    }
    
    @GetMapping({"/", ""})
    public List<Categoria> consultarTodos(){
        List<Categoria> categoriaList = categoriaService.consultarTodos();
        return categoriaList;
    }

    @GetMapping("/{id}")
    public Categoria consultarCategoria(@PathVariable("id") int id){
        Categoria ret = categoriaService.consultarPorId(id);
        return ret;
    }

    @PostMapping({"", "/"})
    public Categoria inserir(@RequestBody Categoria categoria){
        Categoria ret = categoriaService.inserir(categoria);
        return ret;
    }

    @PutMapping({"", "/"})
    public Categoria alterar(@RequestBody Categoria categoria){
        categoriaService.alterar(categoria);
        return categoria;
    }

    @DeleteMapping("/{id}")
    public Categoria alterar(@PathVariable("id") int id){
        Categoria categoria = categoriaService.consultarPorId(id);
        if (categoria == null){
            throw new RuntimeException("Nao existe aluno com este id para ser excluido....");
        }
        categoriaService.excluir(id);
        return categoria;
    }
        
}
