package br.cefet.nagem.service;

import br.cefet.nagem.dao.UsuarioDao;
import br.cefet.nagem.dao.ForumDao;
import br.cefet.nagem.dao.MensagemDao;
import br.cefet.nagem.model.Usuario;
import br.cefet.nagem.model.Forum;
import br.cefet.nagem.model.Mensagem;
import java.util.List;
import org.jdbi.v3.core.Jdbi;
import org.springframework.stereotype.Service;

@Service
public class MensagemService {
    private final MensagemDao mensagemDao;
    private final UsuarioDao usuarioDao;
    private final ForumDao forumDao;

    public MensagemService(Jdbi jdbi) {
        this.mensagemDao = jdbi.onDemand(MensagemDao.class);
        this.usuarioDao = jdbi.onDemand(UsuarioDao.class);
        this.forumDao = jdbi.onDemand(ForumDao.class);
    }

    public Mensagem inserir(Mensagem Mensagem) {
        int idMensagem = mensagemDao.insert(Mensagem);
        Mensagem.setIdMensagem(idMensagem);
        return Mensagem;
    }

    public List<Mensagem> consultarTodos() {
        List<Mensagem> mensagemList = mensagemDao.getAll();

        for (Mensagem mensagem : mensagemList) {
            Usuario usuario = usuarioDao.get(mensagem.getIdUsuario());
            mensagem.setUsuario(usuario);

            Forum forum = forumDao.get(mensagem.getIdUsuario());
            mensagem.setForum(forum);
        }

        return mensagemList;
    }

    public List<Mensagem> consultarMensagensForum(int idForum) {
        List<Mensagem> mensagemList = mensagemDao.getAllByForum(idForum);

        for (Mensagem mensagem : mensagemList) {
            Usuario usuario = usuarioDao.get(mensagem.getIdUsuario());
            mensagem.setUsuario(usuario);

            Forum forum = forumDao.get(mensagem.getIdUsuario());
            mensagem.setForum(forum);
        }

        return mensagemList;
    }

    public Mensagem consultarPorId(int id) {
        Mensagem mensagem = mensagemDao.get(id);

        if (mensagem != null) {
            Usuario usuario = usuarioDao.get(mensagem.getIdUsuario());
            mensagem.setUsuario(usuario);

            Forum forum = forumDao.get(mensagem.getIdUsuario());
            mensagem.setForum(forum);
        }

        return mensagem;
    }

    public void alterar(Mensagem Mensagem) {
        mensagemDao.update(Mensagem);
    }

    public void excluir(int id) {
        mensagemDao.delete(id);
    }

}
