package br.cefet.nagem.dao;

import br.cefet.nagem.model.Genero;
import java.util.List;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

@RegisterBeanMapper(Genero.class)
public interface GeneroDao {

        @GetGeneratedKeys
        @SqlUpdate("insert into genero (descricao) values (:descricao)")
        int insert(@BindBean Genero genero);

        @SqlQuery("select * "
                        + " from genero "
                        + " where idGenero = :idGenero;")
        Genero get(@Bind("idGenero") int idGenero);

        @SqlQuery("select * "
                        + " from genero "
                        + " order by descricao;")
        List<Genero> getAll();

        @SqlQuery("select * "
                        + " from genero "
                        + " where descricao like :descricao "
                        + " order by descricao;")
        List<Genero> getAllByDescricao(@Bind("descricao") String descricao);

        // @SqlQuery("select * "
        //                 + " from genero "
        //                 + " where idCategoria = :idCategoria "
        //                 + " order by descricao;")
        // List<Genero> getAllByCategoria(@Bind("idCategoria") int idCategoria);

        @SqlUpdate("update genero "
                        + " set descricao = :descricao "
                        + " where idGenero = :idGenero;")
        int update(@BindBean Genero genero);

        @SqlUpdate("delete "
                        + " from genero "
                        + " where idGenero = :idGenero;")
        int delete(@Bind("idGenero") int idGenero);

}
