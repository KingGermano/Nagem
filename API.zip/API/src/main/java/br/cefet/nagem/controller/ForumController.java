package br.cefet.nagem.controller;

import br.cefet.nagem.model.Forum;
import br.cefet.nagem.service.ForumService;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/v1/forum")
public class ForumController {

    private final ForumService forumService;

    public ForumController(ForumService forumService){
        this.forumService = forumService;
    }

    @GetMapping({"/", ""})
    public List<Forum> consultarTodos(){
        List<Forum> forumList = forumService.consultarTodos();
        return forumList;
    }

    @GetMapping("/usuario/{idUsuario}")
    public List<Forum> consultarTodosPorUsuario(@PathVariable("idUsuario") int idUsuario){
        List<Forum> forumList = forumService.consultarTodosPorUsuario(idUsuario);
        return forumList;
    }

    @GetMapping("/{id}")
    public Forum consultarForum(@PathVariable("id") int id){
        Forum ret = forumService.consultarPorId(id);
        return ret;
    }

    @PostMapping({"", "/"})
    public Forum inserir(@RequestBody Forum forum){
        Forum ret = forumService.inserir(forum);
        return ret;
    }

    @PutMapping({"", "/"})
    public Forum alterar(@RequestBody Forum forum){
        forumService.alterar(forum);
        return forum;
    }

    @DeleteMapping("/{id}")
    public Forum deletar(@PathVariable("id") int id){
        Forum forum = forumService.consultarPorId(id);
        if (forum == null){
            throw new RuntimeException("Nao existe aluno com este id para ser excluido....");
        }
        forumService.excluir(id);
        return forum;
    }
}
