import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [

  {
    path: '',
    redirectTo: 'inicio',
    pathMatch: 'full'
  },
  {
    path: 'inicio',
    loadChildren: () => import('./pages/inicio/inicio.module').then( m => m.InicioPageModule)
  },
  {
    path: 'login',
    loadChildren: () => import('./pages/login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'menup',
    loadChildren: () => import('./pages/menup/menup.module').then( m => m.MenupPageModule)
  },
  {
    path: 'cadastro',
    loadChildren: () => import('./pages/cadastro/cadastro.module').then( m => m.CadastroPageModule)
  },
  {
    path: 'meusforuns',
    loadChildren: () => import('./pages/meusforuns/meusforuns.module').then( m => m.MeusforunsPageModule)
  },
  {
    path: 'meusdados',
    loadChildren: () => import('./pages/meusdados/meusdados.module').then( m => m.MeusdadosPageModule)
  },
  {
    path: 'forum',
    loadChildren: () => import('./pages/forum/forum.module').then( m => m.ForumPageModule)
  },
  {
    path: 'add-forum',
    loadChildren: () => import('./pages/add-forum/add-forum.module').then( m => m.AddForumPageModule)
  },
  {
    path: 'add-forum/:id',
    loadChildren: () => import('./pages/add-forum/add-forum.module').then( m => m.AddForumPageModule)
  },
  {
    path: 'forum/:id',
    loadChildren: () => import('./pages/forum/forum.module').then( m => m.ForumPageModule)
  },
  {
    path: 'batepapo',
    loadChildren: () => import('./pages/batepapo/batepapo.module').then( m => m.BatepapoPageModule)
  },
  {
    path: 'batepapo/:id',
    loadChildren: () => import('./pages/batepapo/batepapo.module').then( m => m.BatepapoPageModule)
  },
  {
    path: 'genero',
    loadChildren: () => import('./pages/genero/genero.module').then( m => m.GeneroPageModule)
  },
  {
    path: 'categoria',
    loadChildren: () => import('./pages/categoria/categoria.module').then( m => m.CategoriaPageModule)
  },
  {
    path: 'add-genero',
    loadChildren: () => import('./pages/add-genero/add-genero.module').then( m => m.AddGeneroPageModule)
  },
  {
    path: 'add-genero/:id',
    loadChildren: () => import('./pages/add-genero/add-genero.module').then( m => m.AddGeneroPageModule)
  },
  {
    path: 'add-categoria',
    loadChildren: () => import('./pages/add-categoria/add-categoria.module').then( m => m.AddCategoriaPageModule)
  },
  {
    path: 'add-categoria/:id',
    loadChildren: () => import('./pages/add-categoria/add-categoria.module').then( m => m.AddCategoriaPageModule)
  },
  {
    path: 'recuperar-senha',
    loadChildren: () => import('./pages/recuperar-senha/recuperar-senha.module').then( m => m.RecuperarSenhaPageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
