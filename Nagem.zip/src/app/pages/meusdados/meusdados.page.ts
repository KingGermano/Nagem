import { Component, OnInit } from '@angular/core';
import { UsuarioService } from 'src/app/services/usuario.service';
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastController, NavController, AlertController, LoadingController } from '@ionic/angular';
import { Usuario } from 'src/app/model/usuario';

@Component({
  selector: 'app-meusdados',
  templateUrl: './meusdados.page.html',
  styleUrls: ['./meusdados.page.scss'],
})
export class MeusdadosPage implements OnInit {

  formGroup: FormGroup;
  usuario: Usuario;

  constructor(private activatedRoute: ActivatedRoute, private usuarioService: UsuarioService, private fbuilder: FormBuilder, private toastController:
    ToastController, private navController: NavController, private alertController: AlertController, private loadingController: LoadingController) {

    this.usuario = <Usuario>this.usuarioService.getUser();
    console.log(this.usuario)

    this.formGroup = this.fbuilder.group(
      {
        'nick_name': [this.usuario.nick_name, Validators.compose([
          Validators.required,
        ])],
        'email': [this.usuario.email, Validators.compose([
          Validators.required,
        ])],
        'senha': [this.usuario.senha, Validators.compose([
          Validators.required,
        ])],
        'dt_nasc': [this.usuario.dt_nasc, Validators.compose([
          Validators.required,
        ])],
      }
    )

  }

  ngOnInit() {
  }

  salvar() {
    this.usuario.nick_name = this.formGroup.value.nick_name;
    this.usuario.email = this.formGroup.value.email;
    this.usuario.senha = this.formGroup.value.senha;
    this.usuario.dt_nasc = this.formGroup.value.dt_nasc;


    this.usuarioService.salvar(this.usuario).then((json) => {
      let usuarioSalvo = <Usuario>(json);

      if (usuarioSalvo) {
        this.exibirMensagem('Registro alterado!');
        this.navController.navigateBack('/menup');
        this.usuarioService.setUser(usuarioSalvo);
      } else {
        this.exibirMensagem('Erro ao salvar o registro!')
      }
    }).catch((error) => {
      this.exibirMensagem('Erro ao salvar o registro! Erro: ' + error['mensage']);
    });
  }


  async exibirMensagem(texto: string) {
    const toast = await this.toastController.create({
      message: texto,
      duration: 1500
    })
    toast.present();
  }
}
