import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MeusdadosPage } from './meusdados.page';

describe('MeusdadosPage', () => {
  let component: MeusdadosPage;
  let fixture: ComponentFixture<MeusdadosPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(MeusdadosPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
