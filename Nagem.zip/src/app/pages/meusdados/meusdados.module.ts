import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MeusdadosPageRoutingModule } from './meusdados-routing.module';

import { MeusdadosPage } from './meusdados.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MeusdadosPageRoutingModule,
    ReactiveFormsModule
  ],
  declarations: [MeusdadosPage]
})
export class MeusdadosPageModule {}
