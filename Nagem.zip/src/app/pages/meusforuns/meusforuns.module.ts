import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MeusforunsPageRoutingModule } from './meusforuns-routing.module';

import { MeusforunsPage } from './meusforuns.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MeusforunsPageRoutingModule
  ],
  declarations: [MeusforunsPage]
})
export class MeusforunsPageModule {}
