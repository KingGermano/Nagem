import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MeusforunsPage } from './meusforuns.page';

describe('MeusforunsPage', () => {
  let component: MeusforunsPage;
  let fixture: ComponentFixture<MeusforunsPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(MeusforunsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
