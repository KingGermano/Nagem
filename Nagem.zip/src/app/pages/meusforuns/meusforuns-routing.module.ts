import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MeusforunsPage } from './meusforuns.page';

const routes: Routes = [
  {
    path: '',
    component: MeusforunsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MeusforunsPageRoutingModule {}
