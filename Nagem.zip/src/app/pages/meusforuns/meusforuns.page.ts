import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ToastController, NavController, AlertController } from '@ionic/angular';
import { Forum } from 'src/app/model/forum';
import { Usuario } from 'src/app/model/usuario';
import { ForumService } from 'src/app/services/forum.service';
import { UsuarioService } from 'src/app/services/usuario.service';

@Component({
  selector: 'app-meusforuns',
  templateUrl: './meusforuns.page.html',
  styleUrls: ['./meusforuns.page.scss'],
})
export class MeusforunsPage implements OnInit {
  forums: Forum[];
  usuario: Usuario;


  constructor(private forumService: ForumService, private usuarioService: UsuarioService, private toastController: ToastController, private navController: NavController, private alertController: AlertController) {
    this.forums = [];
    this.usuario = this.usuarioService.getUser();
  }

  ngOnInit() {
  }

  async ionViewWillEnter() {
    this.forumService.listarPorIdUsuario(this.usuario.idUsuario).then((json) => {
      this.forums = <Forum[]>(json);
    });
  }

  async exibirMensagem(texto: string) {
    const toast = await this.toastController.create({
      message: texto,
      duration: 1500
    })
    toast.present();
  }
}
