import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-senha',
  templateUrl: './senha.page.html',
  styleUrls: ['./senha.page.scss'],
})
export class SenhaPage implements OnInit {

   isTextFieldType!: boolean;

  constructor(public navCtrl: NavController) { }

  togglePasswordFieldType(){
    this.isTextFieldType = !this.isTextFieldType;
  }


  ngOnInit() {
  }

}
