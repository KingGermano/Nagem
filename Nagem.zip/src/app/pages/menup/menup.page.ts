import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menup',
  templateUrl: './menup.page.html',
  styleUrls: ['./menup.page.scss'],
})
export class MenupPage implements OnInit {
  isAdmin: boolean;
  public appPages = [
    { title: 'Principal', url: '/forum', icon: 'book', color: 'primary' },
    { title: 'Meus Fóruns', url: '/meusforuns', icon: 'chatbubble', color: 'primary' },
    { title: 'Meus Dados', url: '/meusdados', icon: 'person-circle', color: 'primary' },
    { title: 'Sair', url: '/inicio', icon: 'exit', color: 'danger' }
  ];

  public appAdminPages = [
    { title: 'Categorias', url: '/categoria', icon: 'copy', color: 'primary' },
    { title: 'Gêneros', url: '/genero', icon: 'grid', color: 'primary' },
  ]
  constructor() {
    let ok = localStorage.getItem(('admin') || "");
    
    if (ok === "true"){
      this.isAdmin = true;
    } else {
      this.isAdmin = false;
    }   
  }

  ngOnInit() {
  }

}
/*import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  appPages = [
    { title: 'Home', url: '/home', icon: 'home' },
    { title: 'Página 1', url: '/page1', icon: 'document' },
    { title: 'Página 2', url: '/page2', icon: 'document' },
  ];
}*/
