import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MenupPage } from './menup.page';

describe('MenupPage', () => {
  let component: MenupPage;
  let fixture: ComponentFixture<MenupPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(MenupPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
