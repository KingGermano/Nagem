import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { ToastController, NavController, AlertController, IonicModule } from '@ionic/angular';
import { Forum } from 'src/app/model/forum';
import { Usuario } from 'src/app/model/usuario';
import { ForumService } from 'src/app/services/forum.service';
import { UsuarioService } from 'src/app/services/usuario.service';


@Component({
  selector: 'app-forum',
  templateUrl: './forum.page.html',
  styleUrls: ['./forum.page.scss'],
})
export class ForumPage implements OnInit {
  forums: Forum[];

  constructor(private usuarioSerivce: UsuarioService, private forumService: ForumService, private toastController: ToastController, private navController: NavController, private alertController: AlertController) {
    this.forums = [];
  }

  ngOnInit() {
  }

  private idsPermitidos: number[] = [];

  getIdsPermitidos() {
    return this.idsPermitidos;
  }

  adicionarIdPermitido(id: number) {
    this.idsPermitidos.push(id);
  }

  async ionViewWillEnter() {
    this.forumService.listar().then((json) => {
      this.forums = <Forum[]>(json);
    });
  }

  async exibirMensagem(texto: string) {
    const toast = await this.toastController.create({
      message: texto,
      duration: 1500
    })
    toast.present();
  }
}
