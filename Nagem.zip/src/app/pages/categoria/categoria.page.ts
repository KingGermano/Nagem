import { Component, OnInit } from '@angular/core';
import { ToastController } from '@ionic/angular';
import { Categoria } from 'src/app/model/categoria';
import { CategoriaService } from 'src/app/services/categoria.service';

@Component({
  selector: 'app-categoria',
  templateUrl: './categoria.page.html',
  styleUrls: ['./categoria.page.scss'],
})
export class CategoriaPage implements OnInit {
  categorias: Categoria[];

  constructor(private categoriaService: CategoriaService, private toastController: ToastController) {
    this.categorias = [];
  }

  ngOnInit() {
  }

  async ionViewWillEnter() {
    this.categoriaService.listar().then((json) => {
      this.categorias = <Categoria[]>(json);
    })
  }

  async exibirMensagem(texto: string) {
    const toast = await this.toastController.create({
      message: texto,
      duration: 1500
    })
    toast.present();
  }
}
