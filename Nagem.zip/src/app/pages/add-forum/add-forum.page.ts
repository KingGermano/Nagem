import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ToastController, NavController } from '@ionic/angular';
import { Categoria } from 'src/app/model/categoria';
import { Forum } from 'src/app/model/forum';
import { Genero } from 'src/app/model/genero';
import { Usuario } from 'src/app/model/usuario';
import { CategoriaService } from 'src/app/services/categoria.service';
import { ForumService } from 'src/app/services/forum.service';
import { GeneroService } from 'src/app/services/genero.service';
import { UsuarioService } from 'src/app/services/usuario.service';

@Component({
  selector: 'app-add-forum',
  templateUrl: './add-forum.page.html',
  styleUrls: ['./add-forum.page.scss'],
})
export class AddForumPage implements OnInit {
  categorias: Categoria[];
  generos: Genero[];
  forum: Forum;
  formGroup: FormGroup;
  usuario: Usuario;

  constructor(private forumService: ForumService, private categoriaService: CategoriaService, private generoService: GeneroService, private usuarioService: UsuarioService, private activatedRoute: ActivatedRoute, private toastController: ToastController, private navController: NavController, private formBuilder: FormBuilder) {
    this.forum = new Forum();
    this.categorias = [];
    this.generos = [];

    

    this.usuario = usuarioService.getUser();

    this.formGroup = this.formBuilder.group(
      {
        'obra': ["",
          Validators.compose(
            [
              Validators.required
            ])
        ],
        'data': [new Date().toISOString().split('T')[0],
          Validators.compose(
            [
              Validators.required
            ])
        ],
        'categoria': ["",
          Validators.compose(
            [
              Validators.required
            ])
        ],
        'genero': ["",
          Validators.compose(
            [
              Validators.required
            ])
        ],
        'descricao': ["",
          Validators.compose(
            [
              Validators.required,
              Validators.minLength(3)
            ])
        ],

      }
    )

    let id = this.activatedRoute.snapshot.params['id'];

    if (id != null) {

      this.forumService.buscarPorId(parseFloat(id)).then((json) => {
        this.forum = <Forum>(json);

        this.formGroup.get('obra')?.setValue(this.forum.obra);
        this.formGroup.get('data')?.setValue(this.forum.data_forum);
        this.formGroup.get('descricao')?.setValue(this.forum.descricao);
        this.formGroup.get('genero')?.setValue(this.forum.idGenero);
        this.formGroup.get('categoria')?.setValue(this.forum.idCategoria);
      });
    }
  }
  ngOnInit() {
  }

  async ionViewWillEnter() {
    this.categoriaService.listar().then((json) => {
      this.categorias = <Categoria[]>(json);
    });

    this.generoService.listar().then((json) => {
      this.generos = <Genero[]>(json);
    });
  }

  cadastrar() {
    this.forum.obra = this.formGroup.value.obra;
    this.forum.data_forum = this.formGroup.value.data;
    this.forum.descricao = this.formGroup.value.descricao;
    this.forum.idGenero = this.formGroup.value.genero;
    this.forum.idCategoria = this.formGroup.value.categoria;
    this.forum.idUsuario = this.usuario.idUsuario;

    this.forumService.salvar(this.forum).then((json) => {
      let categoriaSalvo = <Categoria>(json);

      if (categoriaSalvo) {
        this.exibirMensagem('Forum salvo!');
        this.navController.navigateBack('/forum');
      } else {
        this.exibirMensagem('Erro ao salvar o registro!')
      }
    }).catch((error) => {
      this.exibirMensagem('Erro ao salvar o registro! Erro: ' + error['mensage']);
    });
  }

  async exibirMensagem(texto: string) {
    const toast = await this.toastController.create({
      message: texto,
      duration: 1500
    });
    toast.present();
  }
}


