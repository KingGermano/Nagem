import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AddForumPage } from './add-forum.page';

describe('AddForumPage', () => {
  let component: AddForumPage;
  let fixture: ComponentFixture<AddForumPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(AddForumPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
