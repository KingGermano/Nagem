import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { BatepapoPageRoutingModule } from './batepapo-routing.module';

import { BatepapoPage } from './batepapo.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ReactiveFormsModule,
    BatepapoPageRoutingModule
  ],
  declarations: [BatepapoPage]
})
export class BatepapoPageModule {}
