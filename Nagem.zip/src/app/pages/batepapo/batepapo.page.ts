import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { AlertController, NavController, ToastController } from '@ionic/angular';
import { Forum } from 'src/app/model/forum';
import { Mensagem } from 'src/app/model/mensagem';
import { Usuario } from 'src/app/model/usuario';
import { Util } from 'src/app/model/util';
import { ForumService } from 'src/app/services/forum.service';
import { MensagemService } from 'src/app/services/mensagem.service';
import { UsuarioService } from 'src/app/services/usuario.service';

@Component({
  selector: 'app-batepapo',
  templateUrl: './batepapo.page.html',
  styleUrls: ['./batepapo.page.scss'],
})
export class BatepapoPage {
  forum: Forum;
  mensagens: Mensagem[];
  mensagemRecente: Mensagem;
  usuario: Usuario;
  formGroup: FormGroup;
  aux: Util;
  numMensagens: number;

  constructor(private alertController: AlertController, private navController: NavController, private toastController: ToastController, private formBuilder: FormBuilder, private activatedRoute: ActivatedRoute, private forumService: ForumService, private mensagemService: MensagemService, private usuarioService: UsuarioService) {
    this.forum = new Forum();
    this.mensagemRecente = new Mensagem();
    this.aux = new Util();
    this.numMensagens = 0;

    this.mensagens = [];
    this.usuario = this.usuarioService.getUser();

    this.formGroup = this.formBuilder.group(
      {
        'texto': ["",
          Validators.compose(
            [
              Validators.required,
              Validators.minLength(4)
            ])
        ],
      }
    );

    let id = this.activatedRoute.snapshot.params['id'];

    if (id != null) {

      this.forumService.buscarPorId(parseFloat(id)).then((json) => {
        this.forum = <Forum>(json);
        this.forumService.formatarData(this.forum);

        this.mensagemService.buscarPorIdForum(this.forum.idForum).then((json) => {
          this.mensagens = <Mensagem[]>(json);
          this.mensagemService.formatarData(this.mensagens);
          // this.numMensagens = this.mensagens.length;
        });
      });
    }
  }

  ngOnInit() {
    // Adicionar um ouvinte de eventos de teclado
    document.addEventListener('keydown', this.handleKeyPress);

    // this.aux.timeOut = setInterval(() => {
    //   this.carregarLista();
    // }, 10000);
  }

  ngOnDestroy() {
    // Remover o ouvinte de eventos de teclado quando a página for destruída
    document.removeEventListener('keydown', this.handleKeyPress);
  }

  handleKeyPress = (event: KeyboardEvent) => {
    if (event.key === 'Enter') {
      // Verificar se a tecla pressionada é a tecla "Enter"
      event.preventDefault(); // Evitar que a quebra de linha seja adicionada ao campo de entrada
    }
  }

  enviarMensagem() {
    this.mensagemRecente.texto = this.formGroup.value.texto;
    this.mensagemRecente.idForum = this.forum.idForum;
    this.mensagemRecente.idUsuario = this.usuario.idUsuario;

    if (this.mensagemRecente.idMensagem === 0) {
      this.mensagemRecente.hora = new Date().toISOString().split('Z')[0];
    }

    this.mensagemRecente.usuario = this.usuario;
    this.mensagemRecente.forum = this.forum;

    this.mensagemService.salvar(this.mensagemRecente).then((json) => {
      let mensagemSalva = <Mensagem>(json);

      if (mensagemSalva) {
        this.exibirMensagem('Mensagem salva!');
        this.carregarLista();
        // this.navController.navigateBack('/forum');
      } else {
        this.exibirMensagem('Erro ao salvar o registro!')
      }
    }).catch((error) => {
      this.exibirMensagem('Erro ao salvar o registro! Erro: ' + error['mensage']);
    });
  }

  async carregarLista() {
    await this.mensagemService.buscarPorIdForum(this.forum.idForum).then((json) => {
      this.mensagens = <Mensagem[]>(json);
      this.mensagemService.formatarData(this.mensagens);

      // if (this.mensagens.length !== this.numMensagens) {
      //   this.exibirMensagem('Uma alteração no número de mensagens foi feita.');
      // }

      // this.numMensagens = this.mensagens.length;
    });
  }

  async exibirMensagem(texto: string) {
    const toast = await this.toastController.create({
      message: texto,
      duration: 1500
    });
    toast.present();
  }

  async excluir(mensagem: Mensagem) {
    const alert = await this.alertController.create({
      header: 'Confirma a exclusão?',
      message: "Usuário: " + mensagem.usuario.nick_name + "\n" + "Hora: " + mensagem.hora,
      buttons: [
        {
          text: 'Cancelar'
        }, {
          text: 'Confirmar',
          cssClass: 'danger',
          handler: () => {
            this.mensagemService.excluir(mensagem.idMensagem).then(() => {
              this.carregarLista();
              this.exibirMensagem('Registro excluído com sucesso!');
            }).catch(() => {
              this.exibirMensagem('Erro ao excluir o registro:');
            });
          }
        }
      ]
    });
    await alert.present();
  }

  alterar(mensagem: Mensagem) {
    this.mensagemRecente = mensagem;
    this.formGroup.get('texto')?.setValue(this.mensagemRecente.texto);
  }

  /*/enviarMensagem() {
    if (this.newMessage.trim() !== '') {
      const currentUserId = 1; // Substitua isso pelo ID do usuário atual
  
      // Verifique se o ID do usuário atual está na lista de IDs permitidos
      if (this.idsPermitidos.includes(currentUserId)) {
        const message = {
          text: this.newMessage,
          userId: currentUserId,
          isMe: true,
        };
        this.messages.push(message);
        this.newMessage = '';
      } else {
        // O ID do usuário atual não está na lista de IDs permitidos
        console.log('Você não está autorizado a enviar mensagens.');
      }
    }
  }/*/




  // Função para enviar uma mensagem
  /*/sendMessage() {
    if (this.newMessage.trim() !== '') {
      const message = {
        text: this.newMessage,
        user: 'Você', // Você pode definir o nome do usuário atual aqui
        isMe: true, // Sinaliza que a mensagem foi enviada pelo usuário atual
      };
      this.messages.push(message); // Adiciona a mensagem ao array de mensagens
      this.newMessage = ''; // Limpa o campo de entrada de texto
    }
  }/*/

}
