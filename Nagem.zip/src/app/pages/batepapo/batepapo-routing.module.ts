import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BatepapoPage } from './batepapo.page';

const routes: Routes = [
  {
    path: '',
    component: BatepapoPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BatepapoPageRoutingModule {}
