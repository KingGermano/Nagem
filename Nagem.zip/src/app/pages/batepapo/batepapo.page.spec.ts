import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BatepapoPage } from './batepapo.page';

describe('BatepapoPage', () => {
  let component: BatepapoPage;
  let fixture: ComponentFixture<BatepapoPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(BatepapoPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
