import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { NavController, ToastController } from '@ionic/angular';
import { Genero } from 'src/app/model/genero';
import { GeneroService } from 'src/app/services/genero.service';

@Component({
  selector: 'app-add-genero',
  templateUrl: './add-genero.page.html',
  styleUrls: ['./add-genero.page.scss'],
})
export class AddGeneroPage implements OnInit {
  genero: Genero;
  formGroup: FormGroup;

  constructor(private generoService: GeneroService, private activatedRoute: ActivatedRoute, private toastController: ToastController, private navController: NavController, private formBuilder: FormBuilder) {
    this.genero = new Genero();

    this.formGroup = this.formBuilder.group(
      {
        'descricao': ["",
          Validators.compose(
            [
              Validators.required,
              Validators.minLength(4)

            ])
        ],
      }
    )

    let id = this.activatedRoute.snapshot.params['id'];

    if (id != null) {

      this.generoService.buscarPorId(id).then((json) => {
        this.genero = <Genero>(json);
        this.formGroup.get('descricao')?.setValue(this.genero.descricao);
      })
    }

  }

  ngOnInit() {
  }

  salvar() {
    this.genero.descricao = this.formGroup.value.descricao;

    this.generoService.salvar(this.genero).then((json) => {
      let generoSalvo = <Genero>(json);

      if (generoSalvo) {
        this.exibirMensagem('Gênero salvo!');
        this.navController.navigateBack('/genero');
      } else {
        this.exibirMensagem('Erro ao salvar o registro!')
      }
    }).catch((error) => {
      this.exibirMensagem('Erro ao salvar o registro! Erro: ' + error['mensage']);
    });
  }

  async exibirMensagem(texto: string) {
    const toast = await this.toastController.create({
      message: texto,
      duration: 1500
    });
    toast.present();
  }
}
