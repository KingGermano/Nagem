import { Component, OnInit } from '@angular/core';
import { Usuario } from 'src/app/model/usuario';
import { ActivatedRoute } from '@angular/router';
import { ToastController } from '@ionic/angular';
import { NavController } from '@ionic/angular';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UsuarioService } from 'src/app/services/usuario.service';

@Component({
  selector: 'app-cadastro',
  templateUrl: './cadastro.page.html',
  styleUrls: ['./cadastro.page.scss'],
})
export class CadastroPage implements OnInit {
  usuario: Usuario;
  formGroup: FormGroup;

  constructor(private usuarioService: UsuarioService, private activatedRoute: ActivatedRoute, private toastController: ToastController, private navController: NavController, private formBuilder: FormBuilder) {
    this.usuario = new Usuario();

    this.formGroup = this.formBuilder.group(
      {
        'nick_name': ["",
          Validators.compose(
            [
              Validators.required,
              Validators.minLength(4)

            ])
        ],
        'email': ["",
          Validators.compose(
            [
              Validators.required,
              Validators.email
            ])
        ],
        'senha': ["",
          Validators.compose(
            [
              Validators.required,
              Validators.minLength(6)
            ])
        ],

        'dt_nasc': [new Date().toISOString().split('T')[0],
          Validators.compose(
            [
              Validators.required
            ])
        ],

      }
    )

    let id = this.activatedRoute.snapshot.params['id'];

    if (id != null) {

      this.usuarioService.buscarPorId(id).then((json) => {
        this.usuario = <Usuario>(json);
        this.formGroup.get('nick_name')?.setValue(this.usuario.nick_name);
        this.formGroup.get('email')?.setValue(this.usuario.email);
        this.formGroup.get('senha')?.setValue(this.usuario.senha)
        this.formGroup.get('dt_nasc')?.setValue(this.usuario.dt_nasc)
      })
    }

  }

  ngOnInit() {
  }

  cadastrar() {
    this.usuario.nick_name = this.formGroup.value.nick_name;
    this.usuario.email = this.formGroup.value.email;
    this.usuario.senha = this.formGroup.value.senha;
    this.usuario.dt_nasc = this.formGroup.value.dt_nasc;

    this.usuarioService.buscarPorEmail(this.usuario.email).then((json) => {
      let resposta = <boolean>(json);

      if (resposta === true) {
        this.exibirMensagem('Email ja existente');
      } else {
        this.usuarioService.salvar(this.usuario).then((json) => {
          let usuarioSalvo = <Usuario>(json);

          if (usuarioSalvo) {
            this.exibirMensagem('Registro salvo!');
            this.navController.navigateBack('/login');
          } else {
            this.exibirMensagem('Erro ao salvar o registro!')
          }
        }).catch((error) => {
          this.exibirMensagem('Erro ao salvar o registro! Erro: ' + error['mensage']);
        });
      }
    })
  }

  async exibirMensagem(texto: string) {
    const toast = await this.toastController.create({
      message: texto,
      duration: 1500
    });
    toast.present();
  }
}
