import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ToastController, NavController } from '@ionic/angular';
import { Categoria } from 'src/app/model/categoria';
import { Forum } from 'src/app/model/forum';
import { Genero } from 'src/app/model/genero';
import { CategoriaService } from 'src/app/services/categoria.service';
import { ForumService } from 'src/app/services/forum.service';
import { GeneroService } from 'src/app/services/genero.service';
import { UsuarioService } from 'src/app/services/usuario.service';

@Component({
  selector: 'app-pesquisar',
  templateUrl: './pesquisar.page.html',
  styleUrls: ['./pesquisar.page.scss'],
})
export class PesquisarPage implements OnInit {

  categorias: Categoria[];
  generos: Genero[];
  forums: Forum[];
  formGroup: FormGroup;

  constructor(private forumService: ForumService, private categoriaService: CategoriaService, private generoService: GeneroService, private usuarioService: UsuarioService, private activatedRoute: ActivatedRoute, private toastController: ToastController, private navController: NavController, private formBuilder: FormBuilder) {
    this.forums = [];
    this.categorias = [];
    this.generos = [];

    this.formGroup = this.formBuilder.group(
      {
        
        'categoria': ["",
          Validators.compose([])
        ],
        'genero': ["",
          Validators.compose([])
        ],

      }
    )
  }

  ngOnInit() {
  }

  async ionViewWillEnter() {
    this.categoriaService.listar().then((json) => {
      this.categorias = <Categoria[]>(json);
    });

    this.generoService.listar().then((json) => {
      this.generos = <Genero[]>(json);
    });
  }

  buscar() {
    let categoria = this.formGroup.value.categoria;
    let genero = this.formGroup.value.genero;

    if (categoria === null) {
      categoria = 0;
    }

    if (genero === null) {
        genero = 0;
    }

    this.forumService.buscar(categoria, genero).then((json) => {
      this.forums = <Forum[]>(json);

      if (this.forums.length === 0) {
        this.exibirMensagem("Nenhum resultado encontrado.");
      }
    });

    this.ionViewWillEnter();
  }

  async exibirMensagem(texto: string) {
    const toast = await this.toastController.create({
      message: texto,
      duration: 1500
    });
    toast.present();
  }
}


