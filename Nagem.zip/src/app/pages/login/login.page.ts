import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { NavController, ToastController } from '@ionic/angular';
import { Usuario } from 'src/app/model/usuario';
import { UsuarioService } from 'src/app/services/usuario.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  usuario: Usuario;
  formGroup: FormGroup;

  constructor(private usuarioService: UsuarioService, private activatedRoute: ActivatedRoute, private toastController: ToastController, private navController: NavController, private formBuilder: FormBuilder) {
    this.usuario = new Usuario();
    this.formGroup = this.formBuilder.group(
      {
        'email': ["",
          Validators.compose(
            [
              Validators.required,
              Validators.email
            ])
        ],
        'senha': ["",
          Validators.compose(
            [
              Validators.required,
              Validators.minLength(6)
            ])
        ],

      }
    )
  }
  ngOnInit() {
  }

  async login() {
    let email = this.formGroup.value.email;
    let senha = this.formGroup.value.senha;

    await this.usuarioService.login(email, senha).then((json) => {
      let usuario = <Usuario>(json);

      if (usuario === null) {
        this.exibirMensagem('Usuário não encontrado.');
      } else {

        this.usuarioService.setUser(usuario);

        this.usuarioService.getIsAdmin(usuario.email).then((json) => {
          let isAdmin = <boolean>(json);

          if (isAdmin === false) {
            this.usuarioService.setIsAdmin("false");
          } else {
            this.usuarioService.setIsAdmin("true");
          }
        });

        this.exibirMensagem('Bem vindo ao sistema!');
        this.navController.navigateBack('/menup')
      }
    });
  }

  async exibirMensagem(texto: string) {
    const toast = await this.toastController.create({
      message: texto,
      duration: 1500
    });
    toast.present();
  }

}
