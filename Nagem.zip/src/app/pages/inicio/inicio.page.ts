import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.page.html',
  styleUrls: ['./inicio.page.scss'],
})
export class InicioPage implements OnInit {

  public appPages = [
    {title: 'Login', url: '/login', icon: 'enter', color: 'primary'},
    {title: 'Cadastro', url: '/cadastro', icon: 'people', color: 'primary'}
  ];

  constructor() {
    localStorage.setItem('usuario', '');
    localStorage.setItem('admin', 'false');
  }

  ngOnInit() {
  }

}