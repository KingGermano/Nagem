import { Component, OnInit } from '@angular/core';
import { ToastController } from '@ionic/angular';
import { Genero } from 'src/app/model/genero';
import { GeneroService } from 'src/app/services/genero.service';

@Component({
  selector: 'app-genero',
  templateUrl: './genero.page.html',
  styleUrls: ['./genero.page.scss'],
})
export class GeneroPage implements OnInit {

  generos: Genero[];

  constructor(private generoService: GeneroService, private toastController: ToastController) {
    this.generos = [];
  }

  ngOnInit() {
  }

  async ionViewWillEnter() {
    this.generoService.listar().then((json) => {
      this.generos = <Genero[]>(json);
    })
  }

  async exibirMensagem(texto: string) {
    const toast = await this.toastController.create({
      message: texto,
      duration: 1500
    })
    toast.present();
  }

}
