import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { NavController, ToastController } from '@ionic/angular';
import { Categoria} from 'src/app/model/categoria';
import { CategoriaService } from 'src/app/services/categoria.service';

@Component({
  selector: 'app-add-categoria',
  templateUrl: './add-categoria.page.html',
  styleUrls: ['./add-categoria.page.scss'],
})
export class AddCategoriaPage implements OnInit {
  categoria: Categoria;
  formGroup: FormGroup;

  constructor(private categoriaService: CategoriaService, private activatedRoute: ActivatedRoute, private toastController: ToastController, private navController: NavController, private formBuilder: FormBuilder) {
    this.categoria = new Categoria();

    this.formGroup = this.formBuilder.group(
      {
        'descricao': ["",
          Validators.compose(
            [
              Validators.required,
              Validators.minLength(4)

            ])
        ],
      }
    )

    let id = this.activatedRoute.snapshot.params['id'];

    if (id != null) {

      this.categoriaService.buscarPorId(id).then((json) => {
        this.categoria = <Categoria>(json);
        this.formGroup.get('descricao')?.setValue(this.categoria.descricao);
      })
    }

  }

  ngOnInit() {
  }

  salvar() {
    this.categoria.descricao = this.formGroup.value.descricao;

    this.categoriaService.salvar(this.categoria).then((json) => {
      let categoriaSalvo = <Categoria>(json);

      if (categoriaSalvo) {
        this.exibirMensagem('Gênero salvo!');
        this.navController.navigateBack('/categoria');
      } else {
        this.exibirMensagem('Erro ao salvar o registro!')
      }
    }).catch((error) => {
      this.exibirMensagem('Erro ao salvar o registro! Erro: ' + error['mensage']);
    });
  }

  async exibirMensagem(texto: string) {
    const toast = await this.toastController.create({
      message: texto,
      duration: 1500
    });
    toast.present();
  }
}