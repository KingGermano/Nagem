import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { UsuarioService } from './services/usuario.service';


@Injectable({
  providedIn: 'root'
})
export class BloqueadorpaginaGuard implements CanActivate {
  usuarioService: UsuarioService;
  constructor(private router: Router) {
    this.usuarioService = new UsuarioService();
  }
  canActivate(): boolean {
    const allowedEmails = ['natannascimentodejesus27@gmail.com'];
    const currentUserEmail = this.usuarioService.getUser();
  
  if(allowedEmails.includes(currentUserEmail)){
    return true;
  }else{
    this.router.navigate(['/menup2']);
    return false;
  }
  }


  
}
