import { Injectable } from '@angular/core';
import { Mensagem } from '../model/mensagem';
import { HttpClient, HttpHeaders} from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class MensagemService {
  formatarData(mensagens: Mensagem[]) {
    for (let i = 0; i < mensagens.length; i++) {
      let resultado = mensagens[i].hora.split(" ");

      let resultadoData = resultado[0].split("-");
      mensagens[i].diaFormatado = resultadoData[2] + "/" + resultadoData[1] + "/" + resultadoData[0];

      let resultadoHora = resultado[1].split(":");
      mensagens[i].horaFormatada = resultadoHora[0] + "h" + resultadoHora[1] + "min";

    }
  }


  httpHeaders = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  }

  url: string = 'http://localhost:8087/api/v1/mensagem';

  constructor(private httpClient: HttpClient) { }

  async buscarPorId(idmensagem: number) {
    let urlAuxiliar = this.url + "/" + idmensagem;
    return await this.httpClient.get(urlAuxiliar).toPromise();
  }

  async salvar(mensagem: Mensagem) {
    if (mensagem.idMensagem === 0) {
      return await this.httpClient.post(this.url, JSON.stringify(mensagem), this.httpHeaders).toPromise();
    } else {
      return await this.httpClient.put(this.url, JSON.stringify(mensagem), this.httpHeaders).toPromise();
    }
  }

  async excluir(idmensagem: number) {
    let urlAuxiliar = this.url + "/" + idmensagem;
    return await this.httpClient.delete(urlAuxiliar).toPromise();
  }

  async listar() {
    return await this.httpClient.get(this.url).toPromise();
  }

  async buscarPorIdForum(idForum: number) {
    let urlAuxiliar = this.url + "/forum/" + idForum;
    return await this.httpClient.get(urlAuxiliar).toPromise();
  }
}
