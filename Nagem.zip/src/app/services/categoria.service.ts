import { Injectable } from '@angular/core';

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Categoria } from '../model/categoria';

@Injectable({
  providedIn: 'root'
})
export class CategoriaService {

  httpHeaders = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  }

  url: string = 'http://localhost:8087/api/v1/categoria';

  constructor(private httpClient: HttpClient) { }

  async buscarPorId(idCategoria: number) {
    let urlAuxiliar = this.url + "/" + idCategoria;
    return await this.httpClient.get(urlAuxiliar).toPromise();
  }

  async salvar(categoria: Categoria) {
    if (categoria.idCategoria === 0) {
      return await this.httpClient.post(this.url, JSON.stringify(categoria), this.httpHeaders).toPromise();
    } else {
      return await this.httpClient.put(this.url, JSON.stringify(categoria), this.httpHeaders).toPromise();
    }
  }

  async excluir(idCategoria: number) {
    let urlAuxiliar = this.url + "/" + idCategoria;
    return await this.httpClient.delete(urlAuxiliar).toPromise();
  }

  async listar() {
    return await this.httpClient.get(this.url).toPromise();
  }
}
