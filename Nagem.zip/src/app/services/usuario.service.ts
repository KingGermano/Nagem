import { Injectable } from '@angular/core';
import { Usuario } from '../model/usuario';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UsuarioService {
 
  httpHeaders = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  }

  url: string = 'http://localhost:8087/api/v1/usuario';

  constructor(private httpClient: HttpClient) { }

  async login(email: string, senha: string) {
    let urlAuxiliar = this.url + "/" + email + "/" + senha + "/authenticate";
    return await this.httpClient.get(urlAuxiliar).toPromise();
  }

  setUser(usuario: Usuario) {
    localStorage.setItem('usuario', JSON.stringify(usuario));
  }

  getUser() {
    return JSON.parse(localStorage.getItem('usuario') || "null");
  }

  setIsAdmin(isAdmin: string) {
    localStorage.setItem('admin', isAdmin);
  }

  async getIsAdmin(email: string) {
    let urlAuxiliar = this.url + "/admin/" + email + "/authenticate/";
    return await this.httpClient.get(urlAuxiliar).toPromise();
  }

  async buscarPorEmail(email: String) {
    let urlAuxiliar = this.url + '/email/' + email + '/exists';
    return await this.httpClient.get(urlAuxiliar).toPromise();
  }

  async buscarPorId(id: number) {
    let urlAuxiliar = this.url + "/" + id;
    return await this.httpClient.get(urlAuxiliar).toPromise();
  }

  async recuperarSenha(email: string) {
    let urlAuxiliar = this.url + "/recover/" + email;
    return await this.httpClient.get(urlAuxiliar).toPromise();
  }

  async salvar(usuario: Usuario) {
    if (usuario.idUsuario === 0) {
      return await this.httpClient.post(this.url, JSON.stringify(usuario), this.httpHeaders).toPromise();
    } else {
      return await this.httpClient.put(this.url, JSON.stringify(usuario), this.httpHeaders).toPromise();
    }
  }

  async excluir(id: number) {
    let urlAuxiliar = this.url + "/" + id;
    return await this.httpClient.delete(urlAuxiliar).toPromise();
  }

  async listar() {
    return await this.httpClient.get(this.url).toPromise();
  }
}