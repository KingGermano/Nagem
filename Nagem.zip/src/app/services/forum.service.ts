import { Injectable } from '@angular/core';
import { Forum } from '../model/forum';
import { HttpClient, HttpHeaders} from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class ForumService {
  formatarData(forum: Forum) {
    let resultado = forum.data_forum.split("-");
    forum.data_forum_formatada = resultado[2] + "/" + resultado[1] + "/" + resultado[0];
  }
  
 
  httpHeaders = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  }

  url: string = 'http://localhost:8087/api/v1/forum';

  constructor(private httpClient: HttpClient) { }

  async buscarPorId(idForum: number) {
    let urlAuxiliar = this.url + "/" + idForum;
    return await this.httpClient.get(urlAuxiliar).toPromise();
  }

  async salvar(forum: Forum) {
    if (forum.idForum === 0) {
      return await this.httpClient.post(this.url, JSON.stringify(forum), this.httpHeaders).toPromise();
    } else {
      return await this.httpClient.put(this.url, JSON.stringify(forum), this.httpHeaders).toPromise();
    }
  }

  async excluir(idForum: number) {
    let urlAuxiliar = this.url + "/" + idForum;
    return await this.httpClient.delete(urlAuxiliar).toPromise();
  }

  async listar() {
    return await this.httpClient.get(this.url).toPromise();
  }

  async listarPorIdUsuario(idUsuario: number) {
    let urlAuxiliar = this.url + "/usuario/" + idUsuario;
    return await this.httpClient.get(urlAuxiliar).toPromise();
  }
}
