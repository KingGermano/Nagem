import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Genero } from '../model/genero';

@Injectable({
  providedIn: 'root'
})
export class GeneroService {

  httpHeaders = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  }

  url: string = 'http://localhost:8087/api/v1/genero';

  constructor(private httpClient: HttpClient) { }

  async buscarPorId(idGenero: number) {
    let urlAuxiliar = this.url + "/" + idGenero;
    return await this.httpClient.get(urlAuxiliar).toPromise();
  }

  async salvar(genero: Genero) {
    if (genero.idGenero === 0) {
      return await this.httpClient.post(this.url, JSON.stringify(genero), this.httpHeaders).toPromise();
    } else {
      return await this.httpClient.put(this.url, JSON.stringify(genero), this.httpHeaders).toPromise();
    }
  }

  async excluir(idGenero: number) {
    let urlAuxiliar = this.url + "/" + idGenero;
    return await this.httpClient.delete(urlAuxiliar).toPromise();
  }

  async listar() {
    return await this.httpClient.get(this.url).toPromise();
  }
}
