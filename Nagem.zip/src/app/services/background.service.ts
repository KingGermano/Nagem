// background.service.ts

import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class BackgroundService {
  private currentIndex = 0;
  private readonly backgrounds = [
    '/assets/icon/foto1Fundo.jpeg',
    '/assets/icon/foto2Fundo.jpg',
    '/assets/icon/foto3Fundo.jpeg',
    // Adicione mais URLs conforme necessário
  ];

  private backgroundSubject = new BehaviorSubject<string>(this.backgrounds[this.currentIndex]);

  changeBackground() {
    this.currentIndex = (this.currentIndex + 1) % this.backgrounds.length;
    this.backgroundSubject.next(this.backgrounds[this.currentIndex]);
  }

  getBackground(): Observable<string> {
    return this.backgroundSubject.asObservable();
  }
}
