import { Mensagem } from './mensagem';

describe('Mensagem', () => {
  it('should create an instance', () => {
    expect(new Mensagem()).toBeTruthy();
  });
});
