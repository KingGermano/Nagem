export class Usuario {
    nick_name: string;
    email: string;
    senha: string;
    idUsuario: number;
    dt_nasc: string;

    constructor(){
        this.nick_name = "";
        this.email = "";
        this.senha = "";
        this.idUsuario = 0;
        this.dt_nasc = "";
    }
}
