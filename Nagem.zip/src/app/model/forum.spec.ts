import { Forum } from './forum';

describe('Forum', () => {
  it('should create an instance', () => {
    expect(new Forum()).toBeTruthy();
  });
});
