import { Forum } from "./forum";
import { Usuario } from "./usuario";

export class Mensagem {
    idMensagem: number;
    texto: string;
    hora: string;
    horaFormatada: string;
    diaFormatado: string;
    idUsuario: number;
    usuario: Usuario;
    idForum: number;
    forum: Forum;

    constructor(){
        this.idMensagem = 0;
        this.texto = "";
        this.hora = "";
        this.horaFormatada = "";
        this.diaFormatado = "";
        this.idUsuario = 0;
        this.usuario = new Usuario();
        this.idForum = 0;
        this.forum = new Forum();
    }
}
