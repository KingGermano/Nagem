export class Categoria {
    idCategoria: number;
    descricao: string;

    constructor(){
        this.idCategoria = 0;
        this.descricao = "";
    }
}
