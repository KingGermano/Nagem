import { Genero } from './genero';

describe('Genero', () => {
  it('should create an instance', () => {
    expect(new Genero()).toBeTruthy();
  });
});
