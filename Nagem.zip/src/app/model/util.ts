export class Util {
    timeOut: any;
}
