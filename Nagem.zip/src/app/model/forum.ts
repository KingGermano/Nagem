import { Categoria } from "./categoria";
import { Genero } from "./genero";
import { Usuario } from "./usuario";

export class Forum {
  idForum: number;
  obra: string;
  data_forum: string;
  data_forum_formatada: string;
  descricao: string;
  idUsuario: number;
  idGenero: number;
  idCategoria: number;
  usuario: Usuario;
  genero: Genero;
  categoria: Categoria;

  constructor() {
    this.idForum = 0;
    this.obra = "";
    this.data_forum = "";
    this.data_forum_formatada = "";
    this.descricao = "";
    this.idGenero = 0;
    this.idCategoria = 0;
    this.idUsuario = 0;
    this.usuario = new Usuario();
    this.genero = new Genero();
    this.categoria = new Categoria();
  }
}
