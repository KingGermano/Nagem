export class Genero {
    idGenero: number;
    descricao: string;

    constructor() {
        this.idGenero = 0;
        this.descricao = "";
    }
}
